            // Fonction pour vérifier la validité de l'email et activer/désactiver le champ de mot de passe en conséquence
            function checkEmailValidity() {
                // Récupérer la valeur de l'email
                var emailValue = document.getElementById("email").value;

                // Vérifier si l'email est valide
                if (isValidEmail(emailValue)) {
                    // Activer le champ de mot de passe
                    document.getElementById("mot_de_passe").removeAttribute("disabled");
                    // Masquer le message d'erreur
                    document.getElementById("error-message").style.display = "none";
                } else {
                    // Désactiver le champ de mot de passe
                    document.getElementById("mot_de_passe").setAttribute("disabled", "disabled");
                    // Afficher un message d'erreur
                    document.getElementById("error-message").style.display = "block";
                }
            }

            // Fonction pour vérifier si une adresse email est valide
            function isValidEmail(email) {
                // Expression régulière pour valider une adresse email
                var emailRegex = /\S+@\S+\.\S+/;
                return emailRegex.test(email);
            }