document.getElementById('insertFilmForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Empêcher le formulaire de se soumettre normalement

    // Récupérer les données du formulaire
    var formData = new FormData(this);

    // Envoyer les données au serveur
    console.log('Envoi des données au serveur...');
    fetch('http://127.0.0.1:5000/insert-film', { // Changement de l'URL vers /insert-film
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (response.ok) {
            console.log('Film inséré avec succès!');
            // Rediriger l'utilisateur vers la page d'accueil en cas de succès
            window.location.href = 'acceuil.html';
        } else {
            // Afficher un message d'erreur en cas d'échec
            console.error('Erreur lors de l\'insertion du film');
        }
    })
    .catch(error => console.error('Erreur :', error));
});