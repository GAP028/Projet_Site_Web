document.getElementById("registration-form").addEventListener("submit", function(event) {
    var nomValue = document.getElementById("nom").value;
    var prenomValue = document.getElementById("prenom").value;
    var emailValue = document.getElementById("email").value;
    var passwordValue = document.getElementById("mot_de_passe").value;

    // Validation du nom
    if (!isValidName(nomValue)) {
        alert("Veuillez saisir un nom valide sans chiffres.");
        event.preventDefault();
        return;
    }

    // Validation du prénom
    if (!isValidName(prenomValue)) {
        alert("Veuillez saisir un prénom valide sans chiffres.");
        event.preventDefault();
        return;
    }

    // Validation de l'email
    if (!isValidEmail(emailValue)) {
        alert("Veuillez saisir une adresse email valide.");
        event.preventDefault();
        return;
    }

    // Validation du mot de passe
    if (passwordValue.length < 6 || passwordValue.length > 20) { // Limite de 20 caractères
        alert("Le mot de passe doit contenir entre 6 et 20 caractères.");
        event.preventDefault();
        return;
    }
});

// Fonction pour vérifier si un nom ou prénom est valide
function isValidName(name) {
    var nameRegex = /^[A-Za-zÀ-ÿ '-]+$/;
    return nameRegex.test(name);
}

// Fonction pour vérifier si une adresse email est valide
function isValidEmail(email) {
    var emailRegex = /\S+@\S+\.\S+/;
    return emailRegex.test(email);
}
