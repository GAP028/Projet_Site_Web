document.addEventListener('DOMContentLoaded', function() {
    // Fonction pour obtenir un nombre aléatoire entre min et max
    function getRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    // Sélection de l'élément parent pour ajouter les points
    const parentElement = document.getElementById('contents');

    // Fonction pour créer un point jaune et l'animer
    function createYellowDot() {
        // Supprimer tous les points jaunes existants
        const existingDots = document.querySelectorAll('.yellow-dot');
        existingDots.forEach(dot => dot.remove());

        // Créer 10 points jaunes simultanément
        for (let i = 0; i < 15; i++) {
            // Création d'un élément div pour le point jaune
            const dot = document.createElement('div');
            dot.classList.add('yellow-dot');

            // Position aléatoire des points sur la page
            const topPosition = getRandomNumber(0, window.innerHeight - 20); // Position verticale aléatoire
            const leftPosition = getRandomNumber(0, window.innerWidth - 20); // Position horizontale aléatoire
            dot.style.top = topPosition + 'px';
            dot.style.left = leftPosition + 'px';

            // Ajout du point à l'élément parent
            parentElement.appendChild(dot);

            // Animation pour faire disparaître et réapparaître le point
            setTimeout(() => {
                dot.style.opacity = '0'; // Faire disparaître le point
                setTimeout(() => {
                    // Repositionner le point à une nouvelle position aléatoire
                    const newTopPosition = getRandomNumber(0, window.innerHeight - 20);
                    const newLeftPosition = getRandomNumber(0, window.innerWidth - 20);
                    dot.style.top = newTopPosition + 'px';
                    dot.style.left = newLeftPosition + 'px';
                    dot.style.opacity = '1'; // Faire réapparaître le point
                }, 3000); // Délai avant de faire réapparaître le point
            }, 3000); // Délai avant de faire disparaître le point
        }
    }

    // Générer 10 points jaunes initiaux
    createYellowDot();

    // Continuer à générer les points jaunes périodiquement
    function generatePeriodicYellowDot() {
        setTimeout(function() {
            createYellowDot();
            generatePeriodicYellowDot();
        }, 5000); // Générer de nouveaux points toutes les 10 secondes
    }

    generatePeriodicYellowDot();
});
