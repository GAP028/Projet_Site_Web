from flask import Flask, request, jsonify, render_template
from classe1 import Utilisateurs, Films
from flask_cors import CORS
import mysql.connector

app = Flask(__name__)
CORS(app)
# Route pour afficher le formulaire d'insertion d'utilisateur
@app.route('/create-user-form')
def create_user_form():
    return render_template('create_user_form.html')

# Route pour gérer la requête POST du formulaire d'insertion d'utilisateur
@app.route('/create-user', methods=['POST'])
def create_user():
    data = request.form
    nom = data.get('nom')
    prenom = data.get('prenom')
    email = data.get('email')
    mot_de_passe = data.get('mot_de_passe')

    # Créer un nouvel utilisateur
    nouvel_utilisateur = Utilisateurs(None, nom, prenom, email, mot_de_passe)
    nouvel_utilisateur.inserer_utilisateur()

    return jsonify({'message': 'Utilisateur créé avec succès'}), 201

# Route pour afficher le formulaire d'insertion de film
@app.route('/insert-film-form')
def insert_film_form():
    return render_template('insert_film_form.html')

# Route pour gérer la requête POST du formulaire d'insertion de film
@app.route('/insert-film', methods=['POST'])
def insert_film():
    titre = request.form['titre']
    genre = request.form['genre']
    annee = request.form['annee']
    realisateur = request.form['realisateur']

    # Créer un nouvel objet Films
    nouveau_film = Films(None, titre, genre, annee, realisateur)
    
    # Insérer le film dans la base de données
    nouveau_film.inserer_film()

    return jsonify({'message': 'Film inséré avec succès'}), 201

if __name__ == '__main__':
    app.run(debug=True)
from flask import Flask, request, jsonify, render_template
from classe1 import Locations
import mysql.connector

app = Flask(__name__)

# Route pour afficher le formulaire de location
@app.route('/location-form')
def location_form():
    return render_template('location_form.html')

# Route pour gérer la requête POST du formulaire de location
@app.route('/create-location', methods=['POST'])
def create_location():
    id_user = request.form['id_user']
    id_film = request.form['id_film']
    date_location = request.form['date_location']

    # Créer un nouvel objet Locations
    nouvelle_location = Locations(None, id_user, id_film, date_location)
    
    # Insérer la location dans la base de données
    nouvelle_location.inserer_location()

    return jsonify({'message': 'Location créée avec succès'}), 201

if __name__ == '__main__':
    app.run(debug=True)
