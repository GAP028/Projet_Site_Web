from abc import ABC, abstractmethod
import mysql.connector

class Utilisateurs(ABC):
    def __init__(self, Id, nom, prenom, email, mdp):
        self.__id = Id
        self.__nom = nom
        self.__prenom = prenom
        self.__email = email
        self.__mdp = mdp
        

    def get_id(self):
        return self.__id

    def set_id(self, Id):
        self.__id = Id

    def get_nom(self):
        return self.__nom

    def set_nom(self, nom):
        self.__nom = nom

    def get_prenom(self):
        return self.__prenom

    def set_prenom(self, prenom):
        self.__prenom = prenom

    def get_email(self):
        return self.__email

    def set_email(self, email):
        self.__email = email

    def get_mdp(self):
        return self.__mdp

    def set_mdp(self, mdp):
        self.__mdp = mdp

    def display_info(self):
        print(self.get_id())
        print(self.get_nom())
        print(self.get_prenom())
        print(self.get_email())
        print(self.get_mdp())

    def update_password_in_database(self, new_password):
        try:
            # Connexion à la base de données
            connection = mysql.connector.connect(
                host="localhost",
                user="root",
                password="root",
                database="projet"
            )

            if connection.is_connected():
                # Création du curseur
                cursor = connection.cursor()

                # Exécution de la requête de mise à jour
                update_query = "UPDATE Utilisateur SET Mot_de_passe = %s WHERE Id = %s"
                data = (new_password, self.__id)
                cursor.execute(update_query, data)

                # Valider les changements
                connection.commit()

                print("Mot de passe mis à jour avec succès dans la base de données.")

        except mysql.connector.Error as err:
            print(f"Erreur lors de la mise à jour du mot de passe dans la base de données: {err}")

        finally:
            # Fermer le curseur et la connexion à la base de données
            if 'connection' in locals() and connection.is_connected():
                cursor.close()
                connection.close()

        self.set_mdp(new_password)

    def inserer_utilisateur(self):
        try:
            # Connexion à la base de données
            connection = mysql.connector.connect(
                host="localhost",
                user="root",
                password="root",
                database="projet"
            )

            if connection.is_connected():
                # Création du curseur
                cursor = connection.cursor()

                # Exécution de la requête d'insertion
                insert_query = "INSERT INTO Utilisateur (Nom, Prenom, Email, Mot_de_passe, Type) VALUES (%s, %s, %s, %s, 'loueur')"
                data = (self.__nom, self.__prenom, self.__email, self.__mdp)
                cursor.execute(insert_query, data)

                # Valider les changements
                connection.commit()

                print("Données insérées avec succès.")

        except mysql.connector.Error as err:
            print(f"Erreur lors de l'insertion des données: {err}")

        finally:
            # Fermer le curseur et la connexion à la base de données
            if 'connection' in locals() and connection.is_connected():
                cursor.close()
                connection.close()

class Gestionnaire(Utilisateurs):
    def __init__(self, Id, nom, prenom, email, mdp):
        super().__init__(Id, nom, prenom, email, mdp)

class Loueurs(Utilisateurs):
    def __init__(self, Id, nom, prenom, email, mdp):
        super().__init__(Id, nom, prenom, email, mdp)
        self.list_location = []

class Films():
    def __init__(self, id, titre, genre, annee, realisateur):
        self.__id = id
        self.titre = titre
        self.genre = genre
        self.annee = annee
        self.realisateur = realisateur
        self.nbre_location = 0

    def get_id(self):
        return self.__id

    def set_id(self, new_id):
        self.__id = new_id

    @classmethod
    def from_input(cls):
        id = input("Entrez l'ID du film: ")
        titre = input("Entrez le titre du film: ")
        genre = input("Entrez le genre du film: ")
        annee = input("Entrez l'année de sortie du film: ")
        realisateur = input("Entrez le réalisateur du film: ")
        return cls(id, titre, genre, annee, realisateur)

    def inserer_film(self):
        try:
            # Connexion à la base de données
            connection = mysql.connector.connect(
                host="localhost",
                user="root",
                password="root",
                database="projet"
            )

            if connection.is_connected():
                # Création du curseur
                cursor = connection.cursor()

                # Exécution de la requête d'insertion
                insert_query = "INSERT INTO Films (Titre, Genre, Annee, Realisateur) VALUES (%s, %s, %s, %s)"
                data = (self.titre, self.genre, self.annee, self.realisateur)
                cursor.execute(insert_query, data)

                # Valider les changements
                connection.commit()

                print("Film inséré avec succès.")

        except mysql.connector.Error as err:
            print(f"Erreur lors de l'insertion du film : {err}")

        finally:
            # Fermer le curseur et la connexion à la base de données
            if 'connection' in locals() and connection.is_connected():
                cursor.close()
                connection.close()

class Locations():
    def __init__(self, id_loc, id_user, id_film, date_location):
        self.id_loc = id_loc
        self.id_user = id_user
        self.id_film = id_film
        self.date_location = date_location
        self.date_retour= None
        self.note=None

    def get_id_user(self):
        return self.id_user

    def set_id_user(self, new_id):
        self.id_user = new_id

    def inserer_location(self):
        try:
            # Connexion à la base de données
            connection = mysql.connector.connect(
                host="localhost",
                user="root",
                password="root",
                database="projet"
            )

            if connection.is_connected():
                # Création du curseur
                cursor = connection.cursor()

                # Exécution de la requête d'insertion
                insert_query = "INSERT INTO Locations (ID_utilisateur, ID_film, Date_location, Date_retour, Note) VALUES (%s, %s, %s, %s, %s)"
                data = (self.id_user, self.id_film, self.date_location, self.date_retour, self.note)
                cursor.execute(insert_query, data)

                # Valider les changements
                connection.commit()

                print("Location insérée avec succès.")

        except mysql.connector.Error as err:
            print(f"Erreur lors de l'insertion de la location : {err}")

        finally:
            # Fermer le curseur et la connexion à la base de données
            if 'connection' in locals() and connection.is_connected():
                cursor.close()
                connection.close()

"""
# Création d'un utilisateur
utilisateur1 = Utilisateurs(1, "Dupont", "Jean", "jean.dupont@example.com", "motdepasse")

# Affichage des informations de l'utilisateur
utilisateur1.display_info()

# Mise à jour du mot de passe dans la base de données
utilisateur1.update_password_in_database("nouveaumotdepasse")

# Insertion de l'utilisateur dans la base de données
utilisateur1.inserer_utilisateur()

# Création d'un gestionnaire
gestionnaire1 = Gestionnaire(2, "Admin", "Gestion", "admin@example.com", "password")

# Création d'un loueur
loueur1 = Loueurs(3, "Smith", "Alice", "alice.smith@example.com", "123456")

# Création d'un film à partir de l'entrée utilisateur
film1 = Films.from_input()

# Insertion du film dans la base de données
film1.inserer_film()

# Création d'une location
location1 = Locations(1, 14, 1, "2024-04-08")

# Insertion de la location dans la base de données
location1.inserer_location()
"""